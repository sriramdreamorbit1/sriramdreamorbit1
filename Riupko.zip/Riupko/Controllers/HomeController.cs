﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Riupko.Models;
using Riupko.Models.Repository;
using Riupko.Controllers;

namespace JQueryDataTables.Controllers
{
    public class HomeController : BaseController
    {
        ProductRepository repository = new ProductRepository();
        /// <summary>
        /// Action that handles initiall request and returns empty view
        /// </summary>
        /// <returns>Home/Index view</returns>
        public ActionResult Index()
        {
                return View();
        }

        /// <summary>
        /// Returns data by the criterion
        /// </summary>
        /// <param name="param">Request sent by DataTables plugin</param>
        /// <returns>JSON text used to display data
        /// <list type="">
        /// <item>sEcho - same value as in the input parameter</item>
        /// <item>iTotalRecords - Total number of unfiltered data. This value is used in the message: 
        /// "Showing *start* to *end* of *iTotalDisplayRecords* entries (filtered from *iTotalDisplayRecords* total entries)
        /// </item>
        /// <item>iTotalDisplayRecords - Total number of filtered data. This value is used in the message: 
        /// "Showing *start* to *end* of *iTotalDisplayRecords* entries (filtered from *iTotalDisplayRecords* total entries)
        /// </item>
        /// <item>aoData - Twodimensional array of values that will be displayed in table. 
        /// Number of columns must match the number of columns in table and number of rows is equal to the number of records that should be displayed in the table</item>
        /// </list>
        /// </returns>
        public JsonResult DataProviderAction(string sEcho, int iDisplayStart, int iDisplayLength)
        {
            var idFilter = Convert.ToString(Request["sSearch_0"]);
            var nameFilter = Convert.ToString(Request["sSearch_1"]);
            var townFilter = Convert.ToString(Request["sSearch_2"]);
            var dateFilter = Convert.ToString(Request["sSearch_3"]);

            var fromID = 0;
            var toID =  0;
            if (idFilter.Contains('~'))
            {
                //Split number range filters with ~
                fromID = idFilter.Split('~')[0] == "" ? 0 : Convert.ToInt32(idFilter.Split('~')[0]);
                toID = idFilter.Split('~')[1] == "" ? 0 : Convert.ToInt32(idFilter.Split('~')[1]);
            }
                       var filteredProducts = repository.GetProducts().ProductList.ToList();
                                    //.Where(c => (fromID == 0 || fromID < c.ID)
                                    //            &&
                                    //            (toID == 0 || c.ID < toID)
                                    //            &&
                                    //            (nameFilter == "" || c.Name.ToLower().Contains(nameFilter.ToLower()))
                                    //            &&
                                    //            (townFilter == "" || c.Town == townFilter)
                                    //            &&
                                    //            (fromDate == DateTime.MinValue || fromDate < c.DateCreated)
                                    //            &&
                                    //            (toDate == DateTime.MaxValue || c.DateCreated < toDate)
                                    //        );

            //Extract only current page
            var displayedProducts = filteredProducts.Skip(iDisplayStart).Take(iDisplayLength);
            //var result = from c in displayedCompanies 
            //                select new[] { 

            //                                c.name
            //                                                                        };
            return Json(new
                            {
                                sEcho = sEcho,
                                iTotalRecords = repository.GetProducts().ProductList.Count(),
                                iTotalDisplayRecords = filteredProducts.Count(),
                                aaData = displayedProducts
            },
                        JsonRequestBehavior.AllowGet);
            
        }

    }
}
