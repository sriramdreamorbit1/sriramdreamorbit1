﻿using Riupko.Models;
using Riupko.Models.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Riupko.Controllers
{
    public class ProductController : BaseController
    {
        ProductRepository repository = new ProductRepository();
        // GET: Product
        public ActionResult Index()
        {
            ProductModel model = new ProductModel();
            model = repository.GetProducts();

            return View(model);
        }
    }
}