﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Riupko.Models
{
    public class ProductModel
    {
        public string name { get; set; }
        public string category { get; set; }
        public string description { get; set; }
        public string filename { get; set; }
        public int height { get; set; }
        public int width { get; set; }
        public decimal price { get; set; }
        public int rating { get; set; }

        public List<ProductModel> ProductList { get; set; }
    }
}