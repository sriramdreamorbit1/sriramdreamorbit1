﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using Newtonsoft.Json;


namespace Riupko.Models.Repository
{
    public class ProductRepository
    {
        public ProductModel GetProducts()
        {
            ProductModel model = new ProductModel();
            using (StreamReader r = new StreamReader("products.json"))
            {
                string json = r.ReadToEnd();
                List<ProductModel> items = JsonConvert.DeserializeObject<List<ProductModel>>(json);

                model.ProductList = items;
               
            }
            return model;
        }
    }
}